import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/home_screen.dart';
import 'package:medicine_reminder/screen/sign_in_screen.dart';
import 'package:sizer/sizer.dart';
import '../commen_Widget/common_button.dart';
import '../commen_Widget/common_text.dart';
import 'bottom_navigation_bar.dart';

class SIGNUP_SCREEN extends StatefulWidget {
  const SIGNUP_SCREEN({Key? key}) : super(key: key);

  @override
  State<SIGNUP_SCREEN> createState() => _SIGNUP_SCREENState();
}

class _SIGNUP_SCREENState extends State<SIGNUP_SCREEN> {
  @override
  void initState() {
    email = TextEditingController();
    password = TextEditingController();
    name = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    email!.dispose();
    password!.dispose();
    name!.dispose();
    super.dispose();
  }

  final _email = GlobalKey<FormState>();
  final _password = GlobalKey<FormState>();
  final _name = GlobalKey<FormState>();
  TextEditingController? email;
  TextEditingController? password;
  TextEditingController? name;
  bool select = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.blueGrey.shade50,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  top: 50, right: 20, left: 20, bottom: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Center(
                        child: Text(
                          "Sign up",
                          style: TextStyle(
                              color: Color(0xff555555), fontSize: 20.sp,fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text(
                    "Tell about yourself",
                    style: TextStyle(
                        color: Color(0xff555555),
                        fontWeight: FontWeight.w800,
                        fontSize: 25.sp),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  Text(
                    "Please give us a little more information about yourself",
                    style: TextStyle(
                        color: Colors.grey, fontSize: 15.sp),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 4.h,
            ),
            Container(
              height: 80.h,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.only(topRight: Radius.circular(50))),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Username",
                        style: TextStyle(
                            color: Color(0xff555555),
                            fontWeight: FontWeight.bold,
                            fontSize: 15.sp),
                      ),
                      SizedBox(
                        height:2.h,
                      ),
                      Form(
                        key: _name,
                        child: Comman_tax(
                          obscur: false,
                          contro: name,
                          hint: "Please enter your username",
                          onchage: (value) {
                            _name.currentState!.validate();
                          },
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "please valid username enter";
                            }
                          },
                          ontap: () {},
                        ),
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Text(
                        "Email",
                        style: TextStyle(
                            color: Color(0xff555555),
                            fontWeight: FontWeight.bold,
                            fontSize: 15.sp),
                      ),
                      SizedBox(
                        height:2.h,
                      ),
                      Form(
                        key: _email,
                        child: Comman_tax(
                          obscur: false,
                          contro: email,
                          hint: "Please enter your email",
                          onchage: (value) {
                            _email.currentState!.validate();
                          },
                          validator: (value) {
                            final bool emailValid = RegExp(
                                    r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                .hasMatch(value!);
                            if (emailValid) {
                              return null;
                            } else {
                              return "please valid email enter";
                            }
                          },
                          ontap: () {},
                        ),
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Text(
                        "Password",
                        style: TextStyle(
                            color: Color(0xff555555),
                            fontWeight: FontWeight.bold,
                            fontSize: 15.sp),
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Form(
                        key: _password,
                        child: Comman_tax(
                          obscur: select,
                          hint: "Please enter your password",
                          sufix: InkWell(
                            onTap: () {
                              setState(() {
                                select = !select;
                              });
                            },
                            child: select == false
                                ? Icon(Icons.visibility)
                                : Icon(Icons.visibility_off),
                          ),
                          contro: password,
                          onchage: (value) {
                            _password.currentState!.validate();
                          },
                          validator: (value) {
                            final bool passwordvalid = RegExp(
                                    r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$')
                                .hasMatch(value!);

                            if (passwordvalid) {
                              return null;
                            } else {
                              return "please valid password enter";
                            }
                          },
                          ontap: () {},
                        ),
                      ),
                      SizedBox(
                        height: 5.h,
                      ),
                     material().button(text: "sign up", ontap: () {
                       if (_name.currentState!.validate() &&
                           _email.currentState!.validate() &&
                           _password.currentState!.validate()) {

                         Navigator.push(context, MaterialPageRoute(builder: (context) => Navigator_bar(),));
                       }
                     },),
                      SizedBox(
                        height: 2.h,
                      ),
                      Center(
                        child: Text(
                          "or",
                          style: TextStyle(
                              color: Colors.grey.shade500,
                              fontSize: 15.sp),
                        ),
                      ),
                      SizedBox(
                        height:2.h,
                      ),
                      InkWell(
                        onTap: () {

                        },
                        child: Container(
                          height: 6.h,
                          width: double.infinity,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset("images/google.png",height: 4.h,),
                              SizedBox(width: 6.w,),
                              Text(
                                "Sign In with Google",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xff555555),
                                    fontSize: 15.sp),
                              ),
                            ],
                          ),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(25),
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 1,
                                    color: Colors.grey.shade300,
                                    spreadRadius: 1,
                                    offset: Offset(0, 1))
                              ]),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
