import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:medicine_reminder/screen/about_us.dart';
import 'package:medicine_reminder/screen/chart_with_doctor.dart';
import 'package:medicine_reminder/screen/community_screen.dart';
import 'package:medicine_reminder/screen/history.dart';
import 'package:medicine_reminder/screen/logout.dart';
import 'package:medicine_reminder/screen/medicine_informaction.dart';
import 'package:medicine_reminder/screen/my_report.dart';
import 'package:medicine_reminder/screen/setting.dart';
import 'package:sizer/sizer.dart';
import 'dart:io';
import 'edit_profile.dart';

class Profile_page extends StatefulWidget {
  const Profile_page({Key? key}) : super(key: key);
  @override
  State<Profile_page> createState() => _Profile_pageState();
}

class _Profile_pageState extends State<Profile_page> {
  ImagePicker imagePicker = ImagePicker();
  File? image;

  choseimage() async {
    final file = await imagePicker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      setState(() {
        image = File(file.path);
      });
    }
  }
  int counter = 0;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey.shade100,
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 6.w,vertical: 3.h),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(onTap: () {
                  Navigator.pop(context);
                },child: Icon(Icons.arrow_back,color: Color(0xff555555),size: 3.5.h)),
                SizedBox(
                  height: 3.h,
                ),
                Text(
                  "Profile",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xff555555),
                    fontSize: 8.5.w,
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Center(
                      child: Stack(
                        children: [
                          Container(
                            width: 25.w,
                            height: 11.h,
                            child: ClipOval(
                              child: image == null
                                  ? SizedBox()
                                  : Image.file(
                                image!,
                                fit: BoxFit.cover,
                              ),
                            ),
                            decoration: BoxDecoration(
                              border: Border.all(
                                  width: 4,
                                  color: Theme.of(context).scaffoldBackgroundColor),
                              shape: BoxShape.circle,
                            ),
                          ),
                          Positioned(
                              bottom: 0,
                              right: 0,
                              child: Container(
                                height: 6.h,
                                width: 8.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    width: 4,
                                    color: Theme.of(context).scaffoldBackgroundColor,
                                  ),
                                  color: Colors.teal.shade400,
                                ),
                                child: InkWell(
                                  onTap: () {
                                    choseimage();
                                  },
                                  child: Icon(
                                    Icons.camera_alt,
                                    color: Colors.white,
                                    size: 2.h,
                                  ),
                                ),
                              )),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 3.w,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Bentdict",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Color(0xff555555),
                              fontSize: 15.sp),
                        ),
                        Text(
                          "Cumberbatch",
                          style:
                              TextStyle(color: Color(0xff555555), fontSize: 15.sp),
                        ),
                      ],
                    ),
                    Spacer(),
                    InkWell(onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>EditProfilePage() ,));
                    },child: Icon(Icons.edit,color: Color(0xff555555),)),
                  ],
                ),
                SizedBox(
                  height: 3.h,
                ),
                ProfileMenu(
                  icon: Icons.medical_information,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => MEDICINE_INFORMCTION(),));
                  },
                  text: "Medicine Informaction",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.chat,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => CHAT_WITH_DOCTOR(),));
                  },
                  text:"chat with doctor",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.assessment,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => MY_REPORT(),));
                  },
                  text: "My Report",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.settings,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SETTINGS(),));
                  },
                  text:  "settings",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.logout,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => LOGOUT(),));
                  },
                  text: "logout",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.group,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => COMUNITY_SCREEN(),));
                  },
                  text: "Community",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.history,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => HISTORY_SCREEN(),));
                  },
                  text: "history",
                ),
                SizedBox(
                  height: 2.h,
                ),
                ProfileMenu(
                  icon: Icons.info,
                  press: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ABOUT_US_SCREEN(),));
                  },
                  text: "About us",
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}




