import 'package:flutter/material.dart';
import 'package:pretty_gauge/pretty_gauge.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:syncfusion_flutter_charts/sparkcharts.dart';
import 'package:sizer/sizer.dart';

import 'hart_rate_screen.dart';
class CHART_SCREEN extends StatefulWidget {
   CHART_SCREEN({super.key,});

  @override
  State<CHART_SCREEN> createState() => _CHART_SCREENState();
}

class _CHART_SCREENState extends State<CHART_SCREEN> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    );
  }
}
