import 'package:flutter/material.dart';

import 'chat_gpt_screen.dart';

class CHAT_WITH_DOCTOR extends StatefulWidget {
  const CHAT_WITH_DOCTOR({Key? key}) : super(key: key);

  @override
  State<CHAT_WITH_DOCTOR> createState() => _CHAT_WITH_DOCTORState();
}

class _CHAT_WITH_DOCTORState extends State<CHAT_WITH_DOCTOR> {
  @override
  Widget build(BuildContext context) {
    return CAHT_GPT_SCREEN();
  }
}
