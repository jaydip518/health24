import 'package:flutter/material.dart';
class MEDICINE_INFORMCTION extends StatefulWidget {
  const MEDICINE_INFORMCTION({Key? key}) : super(key: key);

  @override
  State<MEDICINE_INFORMCTION> createState() => _MEDICINE_INFORMCTIONState();
}

class _MEDICINE_INFORMCTIONState extends State<MEDICINE_INFORMCTION> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
