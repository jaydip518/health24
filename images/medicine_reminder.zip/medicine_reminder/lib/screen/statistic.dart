import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'active_screen.dart';


class Static_page extends StatefulWidget {
  const Static_page({Key? key}) : super(key: key);

  @override
  State<Static_page> createState() => _Static_pageState();
}

class _Static_pageState extends State<Static_page>
    with SingleTickerProviderStateMixin {
  TabController? tabController;
  List list = ["Active", "Campieted"];
  int select = 0;
  void initState() {
    tabController = TabController(length: 2, vsync: this);

    tabController!.addListener(() {
      setState(() {
        select = tabController!.index;
      });
      print("Selected Index: " + tabController!.index.toString());
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 8.h,
            ),
            Text(
              "Statistic",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Color(0xff555555),
                fontSize: 8.5.w,
              ),
            ),
            SizedBox(
              height: 4.h,
            ),
            Center(
              child: TabBar(
                controller: tabController,
                labelPadding: EdgeInsets.zero,
                indicatorPadding: EdgeInsets.zero,
                indicatorColor: Colors.transparent,
                onTap: (value) {
                  setState(() {
                    select = value;
                  });
                },
                tabs: List.generate(
                    2,
                        (index) => Container(
                      height: 5.2.h,
                      width: 50.w,
                      margin: EdgeInsets.only(right: 10),
                      child: Center(
                        child: Text(
                          list[index],
                          style: TextStyle(
                              fontSize: 4.w,
                              color: select == index
                                  ? Colors.white
                                  : Colors.grey.shade800),
                        ),
                      ),
                      decoration: BoxDecoration(
                          color: select != index
                              ? Colors.grey.shade300
                              : Colors.teal.shade400,
                          borderRadius: BorderRadius.circular(14)),
                    )),
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: tabController,
                children: [
                  Active_page(),
                  Active_page(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
