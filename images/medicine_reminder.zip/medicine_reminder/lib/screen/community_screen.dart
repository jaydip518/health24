import 'package:flutter/material.dart';

class COMUNITY_SCREEN extends StatefulWidget {
  const COMUNITY_SCREEN({Key? key}) : super(key: key);

  @override
  State<COMUNITY_SCREEN> createState() => _COMUNITY_SCREENState();
}

class _COMUNITY_SCREENState extends State<COMUNITY_SCREEN> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
