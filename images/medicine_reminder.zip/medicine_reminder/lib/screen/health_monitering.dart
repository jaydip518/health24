import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/bmi_screen.dart';
import 'package:medicine_reminder/screen/hart_rate_screen.dart';
import 'package:medicine_reminder/screen/steps_screen.dart';
import 'package:medicine_reminder/screen/water.dart';
import 'package:sizer/sizer.dart';

class Health_monitoring extends StatefulWidget {
  const Health_monitoring({Key? key}) : super(key: key);

  @override
  State<Health_monitoring> createState() => _Health_monitoringState();
}

class _Health_monitoringState extends State<Health_monitoring> {
  List tax = [
    {
      "tax": "Heart rate",
      "Image": "images/pulse.png",
    },
    {
      "tax": "Water",
      "Image": "images/water.png",
    },
    {
      "tax": "BMI",
      "Image": "images/body-mass-index.png",
    },
    {
      "tax": "Steps",
      "Image": "images/footprint.png",
    },
  ];
  List screen=[
    HEART_RATE_SCREEN(),
    WATER(),
    BMI_SCREEN(),
    STEPS_SCREEN(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 8.h,
              ),
              Text(
                "Health monitoring",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Color(0xff555555),
                  fontSize: 8.5.w,
                ),
              ),
              SizedBox(
                height: 4.h,
              ),
              Column(
                children: List.generate(
                    4,
                    (index) => InkWell(
                          onTap: () {
                            setState(() {
                              screen==index;
                              Navigator.push(context, MaterialPageRoute(builder: (context) => screen[index],));
                            });
                          },
                          child: Container(
                            height: 10.h,
                            width: 100.w,
                            margin: EdgeInsets.symmetric(vertical: 2.h),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.shade200,
                                    spreadRadius: 1,
                                    blurRadius: 1,
                                    offset: Offset(0, 1),
                                  )
                                ],
                                borderRadius: BorderRadius.circular(20)),
                            child: Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceAround,
                              children: [
                                Text(
                                  tax[index]["tax"],
                                  style: TextStyle(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xff555555),
                                  ),
                                ),
                                Image.asset(
                                  tax[index]["Image"],
                                  height: 6.h,
                                ),
                              ],
                            ),
                          ),
                        )),
              )
            ],
          ),
        ),
      ),
    );
  }
}
