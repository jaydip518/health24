import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/sign_in_screen.dart';
import 'package:medicine_reminder/screen/sign_up_screen.dart';
import 'package:sizer/sizer.dart';
import '../commen_Widget/common_button.dart';
import 'bottom_navigation_bar.dart';
import 'package:lottie/lottie.dart';

class WELCOME_SIGNUP extends StatefulWidget {
  const WELCOME_SIGNUP({Key? key}) : super(key: key);

  @override
  State<WELCOME_SIGNUP> createState() => _WELCOME_SIGNUPState();
}

class _WELCOME_SIGNUPState extends State<WELCOME_SIGNUP> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              height: 60.h,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.teal.shade400,
                borderRadius:
                    BorderRadius.only(bottomRight: Radius.circular(65)),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 35, horizontal: 25),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => LOGIN_SCREEN(),
                                ));
                          },
                          child: Text(
                            "Log in",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 18.sp),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Lottie.asset("images/94896-medicine (1).json"),
                ],
              ),
            ),
            SizedBox(
              height: 3.h,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        "Welcome to your\npill reminder!",
                        style: TextStyle(
                            color: Color(0xff555555),
                            fontWeight: FontWeight.bold,
                            fontSize: 26.sp),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 3.h,
                  ),
                  Row(
                    children: [
                      Text(
                        "We will remind you to take your meds,\nand,if necessary,contact your doctor",
                        style: TextStyle(
                            color: Colors.grey.shade400, fontSize: 15.sp),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 4.h,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 2.w),
              child: material().button(
                text: 'Signup',
                ontap: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => SIGNUP_SCREEN(),));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
