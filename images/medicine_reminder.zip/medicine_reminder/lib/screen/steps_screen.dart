import 'package:flutter/material.dart';

class STEPS_SCREEN extends StatefulWidget {
  const STEPS_SCREEN({Key? key}) : super(key: key);

  @override
  State<STEPS_SCREEN> createState() => _STEPS_SCREENState();
}

class _STEPS_SCREENState extends State<STEPS_SCREEN> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
