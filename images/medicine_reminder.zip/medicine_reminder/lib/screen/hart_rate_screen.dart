import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class HEART_RATE_SCREEN extends StatefulWidget {
  @override
  _HEART_RATE_SCREENState createState() => _HEART_RATE_SCREENState();
}

String Age = "Age 1 to 20";
String Height = "4";
var value;



class _HEART_RATE_SCREENState extends State<HEART_RATE_SCREEN> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // floatingActionButton: FloatingActionButton(onPressed: (){
      //   print(Age);
      // },child: Text("submit"),),
      appBar: AppBar(
        title: Text('Heart BPM Demo'),
        backgroundColor: Colors.teal.shade400,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 5.h,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 2.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Text(
                      "Select Age",
                      style: TextStyle(),
                    ),
                    SizedBox(
                      height: 3.h,
                    ),
                    DropdownButton<String>(
                        onChanged: (value) {
                          setState(() {
                            Age = value!;
                          });
                        },
                        underline: SizedBox(),
                        value: Age,
                        //dropdownColor: Colors.teal,
                        items: [
                          DropdownMenuItem(
                              child: Text("Age 1 to 20"), value: "Age 1 to 20"),
                          DropdownMenuItem(
                            child: Text("Age 20 to 30"),
                            value: "Age 20 to 30",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 30 to 40"),
                            value: "Age 30 to 40",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 40 to 50"),
                            value: "Age 40 to 50",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 50 to 60"),
                            value: "Age 50 to 60",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 60 to 70"),
                            value: "Age 60 to 70",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 70 to 80"),
                            value: "Age 70 to 80",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 80 to 90"),
                            value: "Age 80 to 90",
                          ),
                          DropdownMenuItem(
                            child: Text("Age 90 to 100"),
                            value: "Age 90 to 100",
                          ),
                        ]),
                  ],
                ),
                SizedBox(
                  width: 2.w,
                ),
                Column(
                  children: [
                    Text("Select Height"),
                    SizedBox(
                      height: 3.h,
                    ),
                    DropdownButton<String>(
                        onChanged: (value) {
                          setState(() {
                            Height = value!;
                          });
                        },
                        value: Height,
                        underline: SizedBox(),
                        //dropdownColor: Colors.teal,
                        items: [
                          DropdownMenuItem(
                            child: Text("4"),
                            value: "4",
                          ),
                          DropdownMenuItem(
                            child: Text("4.5"),
                            value: "4.5",
                          ),
                          DropdownMenuItem(
                            child: Text("5"),
                            value: "5",
                          ),
                          DropdownMenuItem(
                            child: Text("5.5"),
                            value: "5.5",
                          ),
                          DropdownMenuItem(
                            child: Text("6"),
                            value: "6",
                          ),
                          DropdownMenuItem(
                            child: Text("6.5"),
                            value: "6.5",
                          ),
                          DropdownMenuItem(
                            child: Text(
                              "7",
                            ),
                            value: "7",
                          ),
                          DropdownMenuItem(
                            child: Text("7.5"),
                            value: "7.5",
                          ),
                          DropdownMenuItem(
                            child: Text("8"),
                            value: "8",
                          ),
                        ]),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 5.h,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 6.w),
            child: MaterialButton(
              onPressed: () {
                if (Age == "Age 1 to 20") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 90 BPM")));
                } else if (Age == "Age 20 to 30") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 65 BPM")));
                } else if (Age == "Age 30 to 40") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 70 BPM")));
                } else if (Age == "Age 40 to 50") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 60 BPM")));
                } else if (Age == "Age 50 to 60") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 55 BPM")));
                } else if (Age == "Age 60 to 70") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 52 BPM")));
                } else if (Age == "Age 70 to 80") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 50 BPM")));
                } else if (Age == "Age 80 to 90") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 50 BPM")));
                } else if (Age == "Age 90 to 100") {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text("Heart Bate 45 BPM")));
                }
              },
              minWidth: double.infinity,
              height: 6.h,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25)),
              color: Colors.teal.shade400,
              child: Text(
                "Submit",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          SizedBox(
            height: 5.h,
          ),
        ],
      ),
    );
  }
}
