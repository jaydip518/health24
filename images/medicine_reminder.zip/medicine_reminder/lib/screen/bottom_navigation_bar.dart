import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/home_screen.dart';
import 'package:medicine_reminder/screen/profile.dart';
import 'package:medicine_reminder/screen/statistic.dart';
import 'package:medicine_reminder/screen/video.dart';
import 'package:molten_navigationbar_flutter/molten_navigationbar_flutter.dart';
import 'add_medicine.dart';
import 'health_monitering.dart';

class Navigator_bar extends StatefulWidget {
  const Navigator_bar({Key? key}) : super(key: key);

  @override
  State<Navigator_bar> createState() => _Navigator_barState();
}

class _Navigator_barState extends State<Navigator_bar> {
  int _selectedIndex = 0;
  List select = [
    HOME_SCREEN(),
    Health_monitoring(),
    AddMedicins(),
    Static_page(),
    VIDEO(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      bottomNavigationBar: MoltenBottomNavigationBar(
        curve: Curves.linear,
        barColor: Colors.white,
        barHeight: 60,
        selectedIndex: _selectedIndex,
        domeCircleColor: Colors.teal.shade400,
        onTabChange: (clickedIndex) {
          setState(() {
            _selectedIndex = clickedIndex;
          });
        },
        tabs: [
          MoltenTab(
              icon: Icon(
                Icons.home_filled,
                size: 30,
              )),
          MoltenTab(
              icon: Icon(
                Icons.motion_photos_on_sharp,
                size: 30,
              )),
          MoltenTab(
              icon: Icon(
                Icons.add,
                size: 30,
              )),
          MoltenTab(
              icon: Icon(
                Icons.bar_chart,
                size: 30,
              )),
          MoltenTab(
              icon: Icon(
                Icons.video_collection,
                size: 30,
              )),
        ],
      ),
      body: select[_selectedIndex],
    );
  }
}
