import 'package:flutter/material.dart';

class MY_REPORT extends StatefulWidget {
  const MY_REPORT({Key? key}) : super(key: key);

  @override
  State<MY_REPORT> createState() => _MY_REPORTState();
}

class _MY_REPORTState extends State<MY_REPORT> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
