import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../commen_Widget/common_text.dart';

class EditProfilePage extends StatefulWidget {
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  TextEditingController name = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController locations = TextEditingController();
  TextEditingController number = TextEditingController();
  TextEditingController city = TextEditingController();
  bool showPassword = false;
  ImagePicker imagePicker = ImagePicker();
  File? image;

  choseimage() async {
    final file = await imagePicker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      setState(() {
        image = File(file.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Color(0xff555555),
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(left: 2.5.h, top: 1.1.h, right: 2.h),
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: ListView(
            children: [
              Text(
                "Edit Profile",
                style: TextStyle(fontSize: 6.w, fontWeight: FontWeight.w500),
              ),
              SizedBox(
                height: 2.3.h,
              ),
              Center(
                child: Stack(
                  children: [
                    Container(
                      width: 25.w,
                      height: 11.h,
                      child: ClipOval(
                        child: image == null
                            ? SizedBox()
                            : Image.file(
                          image!,
                          fit: BoxFit.cover,
                        ),
                      ),
                      decoration: BoxDecoration(
                        border: Border.all(
                            width: 4,
                            color: Theme.of(context).scaffoldBackgroundColor),
                        shape: BoxShape.circle,
                      ),
                    ),
                    Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          height: 6.h,
                          width: 8.w,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              width: 4,
                              color: Theme.of(context).scaffoldBackgroundColor,
                            ),
                            color: Colors.teal.shade400,
                          ),
                          child: InkWell(
                            onTap: () {
                              choseimage();
                            },
                            child: Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 2.h,
                            ),
                          ),
                        )),
                  ],
                ),
              ),
              SizedBox(
                height: 4.3.h,
              ),
              Comman_tax(
                obscur: false,
                contro: name,
                //  labal: Text("Full Name"),
                hint: "Dor Alex",
                ontap: () {},
              ),
              SizedBox(
                height: 2.h,
              ),
              Comman_tax(
                obscur: false,
                contro: email,
                // labal: Text("E-mail"),
                hint: "alexd@gmail.com",
                ontap: () {},
              ),
              SizedBox(
                height: 2.h,
              ),
              Comman_tax(
                obscur: false,
                contro: locations,
                hint: "TLV,Israel",
                // labal: Text("Location"),
                ontap: () {},
              ),
              SizedBox(
                height: 2.h,
              ),
              Comman_tax(
                obscur: false,
                contro: name,
                hint: "9987753322",
                //labal: Text("Number"),
                ontap: () {},
              ),
              SizedBox(
                height: 2.h,
              ),
              Comman_tax(
                obscur: false,
                contro: name,
                hint: "Surat",
                //labal: Text("City"),
                ontap: () {},
              ),
              SizedBox(
                height: 6.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    OutlinedButton(
                      onPressed: () {},
                      style: ButtonStyle(
                          shape: MaterialStateProperty.all(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)))),
                      child: Text("CANCEL",
                          style: TextStyle(
                              fontSize: 4.w,
                              letterSpacing: 2.9,
                              color: Colors.black)),
                    ),
                    MaterialButton(
                      onPressed: () {},
                      color: Colors.teal.shade400,
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      child: Text(
                        "SAVE",
                        style: TextStyle(
                            fontSize: 4.w,
                            letterSpacing: 2.2,
                            color: Colors.white),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
