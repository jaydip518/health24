import 'package:flutter/material.dart';

class ABOUT_US_SCREEN extends StatefulWidget {
  const ABOUT_US_SCREEN({Key? key}) : super(key: key);

  @override
  State<ABOUT_US_SCREEN> createState() => _ABOUT_US_SCREENState();
}

class _ABOUT_US_SCREENState extends State<ABOUT_US_SCREEN> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
