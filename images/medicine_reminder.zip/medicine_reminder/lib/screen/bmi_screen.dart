import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_3d_choice_chip/flutter_3d_choice_chip.dart';
import 'package:medicine_reminder/screen/score_screen.dart';
import 'package:sizer/sizer.dart';
import 'package:swipeable_button_view/swipeable_button_view.dart';
import 'age_calculet.dart';
import 'package:page_transition/page_transition.dart';

class BMI_SCREEN extends StatefulWidget {
  const BMI_SCREEN({Key? key}) : super(key: key);

  @override
  State<BMI_SCREEN> createState() => _BMI_SCREENState();
}

class _BMI_SCREENState extends State<BMI_SCREEN> {
  int height = 150;
  int counter = 0;
  int age = 30;
  int weight = 50;
  bool finish = false;
  double bmiScroe = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI"),
        centerTitle: true,
        backgroundColor: Colors.teal.shade400,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 3.h),
          child: Container(
            padding: EdgeInsets.all(12),
            child: Card(
              elevation: 12,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 5.h),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: ChoiceChip3D(
                              border: Border.all(
                                color: Colors.grey,
                              ),
                              style: ChoiceChip3DStyle(
                                  topColor: Colors.white,
                                  backColor: Colors.grey.shade400,
                                  borderRadius: BorderRadius.circular(10)),
                              onSelected: () {
                                setState(() {
                                  counter = 1;
                                });
                              },
                              onUnSelected: () {},
                              selected: counter == 1,
                              child: Padding(
                                padding:
                                const EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  children: [
                                    Image.asset(
                                      "images/man.png",
                                      width: 10.w,
                                    ),
                                    SizedBox(
                                      height: 0.7.h,
                                    ),
                                    Text(
                                      "Male",
                                      style: TextStyle(
                                          fontSize: 13.sp,
                                          color: Color(0xff555555)),
                                    ),
                                  ],
                                ),
                              )),
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: ChoiceChip3D(
                              border: Border.all(
                                color: Colors.grey,
                              ),
                              style: ChoiceChip3DStyle(
                                  topColor: Colors.white,
                                  backColor: Colors.grey.shade400,
                                  borderRadius: BorderRadius.circular(10)),
                              onSelected: () {
                                setState(() {
                                  counter = 2;
                                });
                              },
                              onUnSelected: () {},
                              selected: counter == 2,
                              child: Padding(
                                padding:
                                const EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  children: [
                                    Image.asset(
                                      "images/woman.png",
                                      width: 10.w,
                                    ),
                                    SizedBox(
                                      height: 0.7.h,
                                    ),
                                    Text("Female",
                                        style: TextStyle(
                                            fontSize: 13.sp,
                                            color: Color(0xff555555))),
                                  ],
                                ),
                              )),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 5.w),
                      child: Card(
                        elevation: 15,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        child: Column(
                          children: [
                            SizedBox(
                              height: 1.h,
                            ),
                            Text(
                              "Height",
                              style: TextStyle(
                                  fontSize: 20.sp, color: Color(0xff555555)),
                            ),
                            SizedBox(
                              height: 1.h,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(height.toString(),
                                    style: TextStyle(
                                        fontSize: 20.sp,
                                        color: Color(0xff555555))),
                                Text("cm",
                                    style: TextStyle(
                                        fontSize: 15.sp,
                                        color: Color(0xff555555)))
                              ],
                            ),
                            SizedBox(
                              height: 1.h,
                            ),
                            Slider(
                              activeColor: Colors.teal.shade400,
                              value: height.toDouble(),
                              onChanged: (value) {
                                setState(() {
                                  height = value.toInt();
                                });
                              },
                              min: 0,
                              max: 240,
                            )
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AGE_CALCULATE(
                          onchange: (ageval) {
                            age = ageval;
                          },
                          title: 'Age',
                          invalue: 30,
                          min: 0,
                          max: 100,
                        ),
                        SizedBox(
                          width: 5.w,
                        ),
                        AGE_CALCULATE(
                          onchange: (ageval) {
                            weight = ageval;
                          },
                          title: 'Weight(Kg)',
                          invalue: 50,
                          min: 0,
                          max: 200,
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 7.h,
                    ),
                    Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 5.w),
                      child: SwipeableButtonView(onFinish: () async{
                        await Navigator.push(context, PageTransition(child: SCORE_SCREEN(bmiscore: bmiScroe, age: age), type: PageTransitionType.fade));
                        setState(() {
                          finish=false;
                        });
                      },
                          isFinished: finish,
                          onWaitingProcess: () {
                            calculateBmi();
                        Future.delayed(Duration(seconds: 1),() {
                          setState(() {
                            finish=true;
                          });
                        },);
                          },
                          activeColor: Colors.teal,
                          buttonWidget: Icon(Icons.arrow_forward_ios),
                          buttonText: "CALCULATE"),
                    ),
                    SizedBox(
                      height: 1.h,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void calculateBmi() {
    bmiScroe = weight / pow(height / 100, 2);
  }
}
