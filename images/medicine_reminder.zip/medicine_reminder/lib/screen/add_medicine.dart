import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:table_calendar/table_calendar.dart';
import '../commen_Widget/common_button.dart';
import '../commen_Widget/common_text.dart';


class AddMedicins extends StatefulWidget {
  const AddMedicins({Key? key}) : super(key: key);

  @override
  State<AddMedicins> createState() => _AddMedicinsState();
}

class _AddMedicinsState extends State<AddMedicins> {
  TimeOfDay? time;
  TimeOfDay? picker;

  @override
  void initState() {
    super.initState();
    time = TimeOfDay.now();
  }

  Future<Null> selectTime(BuildContext context) async {
    picker = await showTimePicker(context: context, initialTime: time!);

    if (picker != null) {
      setState(() {
        time = picker;
      });
    }
  }

  String? gender;
  String? days;

  int selectMedicin = 0;

  List Map = [
    {
      "image": "https://cdn-icons-png.flaticon.com/128/807/807165.png",
      "medi": "Tablets",
    },
    {
      "image": "https://cdn-icons-png.flaticon.com/128/822/822092.png",
      "medi": "Capsule",
    },
    {
      "image": "https://cdn-icons-png.flaticon.com/128/4148/4148500.png",
      "medi": "Injection",
    },
    {
      "image": "https://cdn-icons-png.flaticon.com/128/9408/9408727.png",
      "medi": "Bottle",
    },
    {
      "image": "https://cdn-icons-png.flaticon.com/128/673/673561.png",
      "medi": "Home Made",
    },
    {
      "image": "https://cdn-icons-png.flaticon.com/128/2447/2447774.png",
      "medi": "Water",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding:EdgeInsets.only(left: 5.w,right: 5.w,top: 5.h),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Add Plan",
                      style: TextStyle(
                          color:Color(0xff555555),
                          fontSize: 22.sp,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: BouncingScrollPhysics(),
                child: Row(
                    children: List.generate(
                        6,
                            (index) => Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectMedicin = index;
                              });
                            },
                            child: Column(
                              children: [
                                SizedBox(height: 4.h),
                                Container(
                                  height: 10.h,
                                  width: 20.w,
                                  child: Center(
                                      child: Image.network(
                                        Map[index]["image"],
                                        width: 12.w,
                                      )),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: selectMedicin == index
                                              ? Colors.teal.shade400
                                              : Colors.transparent,
                                          width: 3),
                                      shape: BoxShape.circle,
                                      color: Colors.white),
                                ),
                                SizedBox(height: 1.5.h),
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      selectMedicin = index;
                                    });
                                  },
                                  child: Text(
                                    Map[index]["medi"],
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: selectMedicin == index
                                            ? Colors.teal.shade400
                                            : Colors.grey),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ))),
              ),
              SizedBox(height: 4.h),
              Row(
                children: [
                  Text(
                    "Medication",
                    style: TextStyle(
                        color:Color(0xff555555), fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              Comman_tax(
                ontap: () {},
                hint: " Medicine Name",
                obscur: false,
              ),
              SizedBox(height: 2.h),
              Comman_tax(
                ontap: () {},
                hint: " Description",
                obscur: false,

              ),
              SizedBox(height: 3.h),
              Row(
                children: [
                  Text(
                    "Set Reminder",
                    style: TextStyle(
                        color:Color(0xff555555), fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(
                height: 1.h,
              ),
              Row(
                children: [
                  InkWell(
                    onTap: () {
                      selectTime(context);
                    },
                    child: Container(
                      height: 5.5.h,
                      width: 45.w,
                      child: Row(
                        children: [
                          SizedBox(
                            width: 4.w,
                          ),
                          IconButton(
                              onPressed: () {
                                selectTime(context);
                              },
                              icon: Icon(Icons.alarm,color: Color(0xff555555),)),
                          Text("Time  ${time!.hour}:${time!.minute}",style: TextStyle(color:Color(0xff555555))),
                          SizedBox(
                            width: 2.w,
                          ),
                        ],
                      ),
                      decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: Colors.grey.shade400)),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 3.h,
              ),
              Row(
                children: [
                  Text(
                    "Shedual",
                    style: TextStyle(
                        color:Color(0xff555555), fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 1.h),
              Row(
                children: [
                  Text(
                    "Start date",
                    style: TextStyle(color: Colors.grey, fontSize: 14.sp),
                  ),
                  SizedBox(
                    width: 2.w,
                  ),
                  InkWell(
                    onTap: () {
                      showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2001),
                          lastDate: DateTime(2050));
                    },
                    child: Container(
                      height: 4.h,
                      width: 30.w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "23/01/2023",
                            style: TextStyle(
                                color: Colors.grey, fontSize: 11.sp),
                          )
                        ],
                      ),
                      decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: Colors.grey.shade400)),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 4.h,
              ),
              Row(
                children: [
                  Text(
                    "Duration",
                    style: TextStyle(color: Colors.grey, fontSize: 14.sp),
                  ),
                ],
              ),
              SizedBox(
                height: 3.h,
              ),
              RadioListTile(
                title: Text("Every day",style: TextStyle(color:Color(0xff555555)),),
                value: "day",
                groupValue: gender,
                onChanged: (value) {
                  setState(() {
                    gender = value.toString();
                  });
                },
              ),
              RadioListTile(
                title: Text("Number of day",style: TextStyle(color:Color(0xff555555))),
                value: "female",
                groupValue: gender,
                onChanged: (value) {
                  setState(() {
                    gender = value.toString();
                  });
                },
              ),
              RadioListTile(
                title: Text("Specific day of week",style: TextStyle(color:Color(0xff555555))),
                value: "other",
                groupValue: gender,
                onChanged: (value) {
                  setState(() {
                    gender = value.toString();
                  });
                },
              ),
              SizedBox(
                height: 3.h,
              ),
              material().button(text: "Add Medicine", ontap: () {

              },),
              SizedBox(
                height: 3.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
