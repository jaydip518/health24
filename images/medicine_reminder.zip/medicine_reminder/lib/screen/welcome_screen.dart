import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/home_screen.dart';
import 'package:sizer/sizer.dart';
import 'package:medicine_reminder/screen/sign_up_screen.dart';
import 'package:medicine_reminder/screen/welcome_sign_up.dart';

import 'bottom_navigation_bar.dart';

class WELCOME_SCREEN extends StatefulWidget {
  const WELCOME_SCREEN({Key? key}) : super(key: key);

  @override
  State<WELCOME_SCREEN> createState() => _WELCOME_SCREENState();
}

class _WELCOME_SCREENState extends State<WELCOME_SCREEN> {
  List items = [
    {
      'image':"images/image1.png",
      'title': 'Reception drug',
      'subtitle':
          'Add,edit,track admission your drugs\nin two clicks.Making a drug from\nyour phone is as easy.',
    },
    {
      'image':"images/image2.png",
      'title': 'Monitoring health',
      'subtitle':
          'View history your well-being after taking\ndrug in one clickCommon Review Mission  Monitoring Reports.',
    },
    {
      'image':"images/image3.png",
      'title': 'Get notified',
      'subtitle':
          'Our system will your of all does of the drug,so you donot have to keep everything in your mind.',
    },
  ];
  int counter = 0;

  PageController? pageController;

  @override
  void initState() {
    pageController = PageController(initialPage: 0);
    super.initState();
  }

  @override
  void dispose() {
    pageController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30,vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(onTap: () {
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => Navigator_bar(),));
                  },child: Padding(
                    padding:  EdgeInsets.only(right: 2.w,top: 3.h),
                    child: Text("Skip",style: TextStyle(color: Colors.teal.shade400,fontSize: 15.sp,fontWeight: FontWeight.bold),),
                  )),
                ],
              ),
            ),
            SizedBox(
              height: 55.h,
              child: PageView.builder(

                controller: pageController,
                onPageChanged: (value) {
                  setState(() {
                    counter = value;
                  });
                },
                itemCount: items.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 2.h,
                        ),
                        Image.asset(items[index]['image'],height: 30.h,),
                        SizedBox(
                          height: 3.h,
                        ),
                        Text(
                          items[index]['title'],
                          style: TextStyle(
                              fontSize: 8.w,
                              color: Color(0xff555555),
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        Text(
                          items[index]['subtitle'],
                          style: TextStyle(
                              fontSize: 5.w, color: Colors.grey),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              height: 3.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                  3,
                      (index) => Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 5),
                    child: CircleAvatar(
                      backgroundColor: counter == index
                          ? Colors.teal.shade400
                          : Colors.grey,
                      maxRadius: 3.5,
                    ),
                  )),
            ),
            SizedBox(
              height: 7.h,
            ),
            MaterialButton(
              onPressed: () {
                if (counter == items.length - 1){
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => WELCOME_SIGNUP(),));
                }
                pageController!.nextPage(duration: Duration(microseconds: 100), curve: Curves.bounceIn);
              },
              child: Text(
                counter == items.length - 1 ? "Get Started" : "Next",
                style: TextStyle(color: Colors.white,fontSize: 13.sp),
              ),
              minWidth: 80.w,
              height: 6.h,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
              color: Colors.teal.shade400,
            )
          ],
        ),
      ),
    );
  }
}
