import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class Active_page extends StatefulWidget {
  const Active_page({Key? key}) : super(key: key);

  @override
  State<Active_page> createState() => _Active_pageState();
}

class _Active_pageState extends State<Active_page> {
  List tax = [
    {
      "tax": "Cinupret",
      "tax1": "19.06.22- 19-07-22",
    },
    {
      "tax": "Orthomol",
      "tax1": "19.06.22-19-07-22",
    },
    {
      "tax": "Centrum",
      "tax1": "19.06.22-19-07-22",
    },
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              itemCount: 3,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisExtent: 25.h,
                crossAxisSpacing: 10,
                mainAxisSpacing: 15,
              ),
              itemBuilder: (context, index) {
                return Container(
                  height: 90.h,
                  width: 60.w,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 12.h,
                        ),
                        Text(
                          tax[index]["tax"],
                          style: TextStyle(
                              fontSize: 16.sp,
                              color: Colors.black,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 1.9.h,
                        ),
                        Text(
                          tax[index]["tax1"],
                          style: TextStyle(
                              fontSize: 10.sp,
                              color: Colors.grey.shade500,
                              fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          height: 1.5.h,
                        ),
                        Center(
                          child: Container(
                            height: 3.1.h,
                            width: 38.w,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            offset: Offset(1, 1),
                            color: Colors.grey.shade200,
                            spreadRadius: 1,
                            blurRadius: 1),
                      ],
                      borderRadius: BorderRadius.circular(14)),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
