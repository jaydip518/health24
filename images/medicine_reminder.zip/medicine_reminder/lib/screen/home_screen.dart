import 'package:date_picker_timeline/date_picker_timeline.dart';
import 'package:flutter/material.dart';
import 'package:health/health.dart';
import 'package:medicine_reminder/screen/bottom_navigation_bar.dart';
import 'package:medicine_reminder/screen/profile.dart';
import 'package:sizer/sizer.dart';
import 'package:intl/intl.dart';

class HOME_SCREEN extends StatefulWidget {
  const HOME_SCREEN({Key? key}) : super(key: key);

  @override
  State<HOME_SCREEN> createState() => _HOME_SCREENState();
}

class _HOME_SCREENState extends State<HOME_SCREEN> {
  List cate = [
    {
      'title': 'SATURATION',
      'image': "",
      'per': '99',
      'per2': '%',
      'subtitle': 'Last update:6h',
    },
    {
      'title': 'HEART RATE',
      'image': "",
      'per': '91',
      'per2': 'bpm',
      'subtitle': 'Last update:3h',
    },
    {
      'title': 'PRESSURE',
      'image': "",
      'per': '120/80',
      'per2': 'mmHg',
      'subtitle': 'Last update:5h',
    },
    {
      'title': 'TEMPERATURE',
      'image': "",
      'per': '37.8',
      'per2': 'C',
      'subtitle': 'Last update:4h',
    },
  ];
  DateTime? _dateTime = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => Profile_page(),));
                      },
                      child: Container(
                        height: 4.h,
                        width: 4.h,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                        ),
                        child: Image.asset("images/man.png"),
                      ),
                    ),
                    Text(
                      "Your plan",
                      style: TextStyle(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.bold,
                          color: Color(0xff555555)),
                    ),
                    Text(
                      DateFormat.yMMMd().format(DateTime.now()),
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                child: Container(
                  child: DatePicker(
                    DateTime.now(),
                    height: 11.h,
                    width: 16.w,
                    initialSelectedDate: DateTime.now(),
                    selectedTextColor: Colors.white,
                    selectionColor: Colors.teal,
                    dateTextStyle: TextStyle(
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey),
                    monthTextStyle: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey),
                    dayTextStyle: TextStyle(
                        fontSize: 10.sp,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey),
                    onDateChange: (selectedDate) {
                      _dateTime = selectedDate;
                    },
                  ),
                ),
              ),
              SizedBox(
                height: 3.h,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w),
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: 4,
                  scrollDirection: Axis.vertical,
                  itemBuilder: (context, index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 22.h,
                          width: 60.w,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(
                              20,
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 2.h, vertical: 2.h),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  cate[index]['title'],
                                  style: TextStyle(
                                      color: Color(0xff555555),
                                      fontWeight: FontWeight.w600),
                                ),
                                SizedBox(
                                  height: 8.h,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      cate[index]['per'],
                                      style: TextStyle(
                                          color: Colors.green.shade500,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 17.sp),
                                    ),
                                    SizedBox(
                                      width: 1.w,
                                    ),
                                    Text(
                                      cate[index]['per2'].toString(),
                                      style: TextStyle(
                                          color: Colors.grey, fontSize: 12.sp),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 1.h,
                                ),
                                Text(
                                  cate[index]['subtitle'],
                                  style: TextStyle(
                                      color: Colors.grey, fontSize: 10.sp),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 13,
                      mainAxisExtent: 50.w,
                      mainAxisSpacing: 15),
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: 3,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Container(
                      height: 10.h,
                      width: double.infinity,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20)),
                      margin: EdgeInsets.symmetric(vertical: 1.h),
                      child: ListTile(
                        leading: Icon(
                          Icons.medical_information,
                          color: Colors.teal.shade400,
                        ),
                        title: Text(
                          "Cinupert",
                          style: TextStyle(
                              color: Color(0xff555555),
                              fontWeight: FontWeight.w600),
                        ),
                        subtitle: Text("2 pills"),
                        trailing: Icon(
                          Icons.more_horiz,
                          color: Colors.teal.shade400,
                        ),
                      ),
                    ),
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
