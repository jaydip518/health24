import 'dart:async';
import 'package:sizer/sizer.dart';

import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/sign_up_screen.dart';
import 'package:medicine_reminder/screen/welcome_screen.dart';
import 'package:medicine_reminder/screen/welcome_sign_up.dart';


class SPLASH_SCREEN extends StatefulWidget {
  const SPLASH_SCREEN({Key? key}) : super(key: key);

  @override
  State<SPLASH_SCREEN> createState() => _SPLASH_SCREENState();
}

class _SPLASH_SCREENState extends State<SPLASH_SCREEN> {
  @override
  void initState() {
    Timer(Duration(seconds: 3), () { Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => WELCOME_SCREEN(),));});
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset("images/logo-removebg-preview.png",width: 30.w,),
          SizedBox(height: 3.h,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Health",style: TextStyle(color: Colors.teal.shade400,fontStyle: FontStyle.italic,fontSize: 35.sp,fontWeight: FontWeight.w900),),
              Text("24",style: TextStyle(color: Colors.orange.shade600,fontStyle: FontStyle.italic,fontSize: 35.sp,fontWeight: FontWeight.w900),),
            ],
          )
        ],
      ),
    );
  }
}


