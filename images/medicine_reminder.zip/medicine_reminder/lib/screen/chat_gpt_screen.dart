import 'dart:async';
import 'package:chat_gpt_sdk/chat_gpt_sdk.dart';
import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/threedots.dart';
import 'package:velocity_x/velocity_x.dart';
import 'package:sizer/sizer.dart';
import 'chat_message.dart';

class CAHT_GPT_SCREEN extends StatefulWidget {
  const CAHT_GPT_SCREEN({Key? key}) : super(key: key);

  @override
  State<CAHT_GPT_SCREEN> createState() => _CAHT_GPT_SCREENState();
}

class _CAHT_GPT_SCREENState extends State<CAHT_GPT_SCREEN> {
  final TextEditingController _controller = TextEditingController();
  final List<ChatMessage> _message = [];
  ChatGPT? chatGPT;
  StreamSubscription? _streamSubscription;
  bool _isTyping = false;

  @override
  void initState() {
    chatGPT = ChatGPT.instance;
    super.initState();
  }

  @override
  void dispose() {
    _streamSubscription?.cancel();
    super.dispose();
  }

  void _sendMessage() {
    ChatMessage message = ChatMessage(text: _controller.text, sender: "user");
    setState(() {
      _message.insert(0, message);
      _isTyping = true;
    });
    _controller.clear();

    final request = CompleteReq(
        prompt: message.text, model: kTranslateModelV2, max_tokens: 200);

    _streamSubscription = chatGPT!
        .builder("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",
        orgId: "")
        .onCompleteStream(request: request)
        .listen((response) {
          if(response==null){
            ScaffoldMessenger.of(context)
                .showSnackBar(SnackBar(content: Text("error")));

          }else{
            Vx.log(response.choices[0].text);

            ChatMessage botMeaage = ChatMessage(text: response.choices[0].text, sender: "Doctor");

            setState(() {
              _message.insert(0, botMeaage);
              _isTyping = false;
            });
          }

    });
  }

  Widget _buildTextComposer() {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _controller,
            onSubmitted: (value) => _sendMessage(),
            decoration: InputDecoration.collapsed(hintText: "Send a message"),
          ),
        ),
        IconButton(
          onPressed: () => _sendMessage(),
          icon: Icon(Icons.send),
        ),
      ],
    ).px16();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat With Doctor"),
        centerTitle: true,
        backgroundColor: Colors.teal.shade400,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Flexible(
              child: ListView.builder(
                reverse: true,
                padding: Vx.m8,
                itemCount: _message.length,
                itemBuilder: (context, index) {
                  return _message[index];
                },
              ),
            ),
            //if (_isTyping) ThreeDots(),
            Divider(
              height: 1.0,
            ),
            Padding(
              padding: EdgeInsets.only(bottom: 1.5.h),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                ),
                child: _buildTextComposer(),
              ),
            )
          ],
        ),
      ),
    );
  }
}
