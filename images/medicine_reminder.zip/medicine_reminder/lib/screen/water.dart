import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
class WATER extends StatefulWidget {
  const WATER({Key? key}) : super(key: key);

  @override
  State<WATER> createState() => _WATERState();
}

class _WATERState extends State<WATER> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body:SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  height: 45.h,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.teal.shade400,
                    borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
                  ),
                  child: Padding(
                    padding:  EdgeInsets.symmetric(vertical: 2.h),
                    child: Column(
                      children: [
                        Center(child: Text("Drinking water",style: TextStyle(color: Colors.white,fontSize: 18.sp),)),
                        SizedBox(height: 5.h,),
                        Image.asset("images/glass-of-water.png",height: 12.h,),
                        SizedBox(height: 5.h,),
                        Text("notify you drink water on time",style: TextStyle(color: Colors.white,fontSize: 15.sp),)
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: -350,
                  child: Padding(
                    padding:  EdgeInsets.symmetric(horizontal: 4.w),
                    child: Container(
                      height: 53.h,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [BoxShadow(color: Colors.grey.shade500,spreadRadius: 0.5,blurRadius: 0.5)]
                      ),
                      child: Padding(
                        padding:  EdgeInsets.symmetric(horizontal: 5.w,vertical: 2.h),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text("Drinking water reminder",style: TextStyle(fontSize: 13.sp),),
                                Spacer(),
                                Switch(value: false, onChanged: (value) {

                                },)
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      )
    );
  }
}
