import 'package:flutter/material.dart';
import 'package:medicine_reminder/screen/profile.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:get/get.dart';

class SETTINGS extends StatefulWidget {
  const SETTINGS({Key? key}) : super(key: key);

  @override
  State<SETTINGS> createState() => _SETTINGSState();
}

class _SETTINGSState extends State<SETTINGS> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: 7.w,vertical: 4.h),
              child: Row(
                children: [
                InkWell(onTap: () {
                  Navigator.pop(context);
                },child: Icon(Icons.arrow_back_ios,size: 3.h,color: Color(0xff555555),)),
                ],
              ),
            ),
            Text("User Settings",style: TextStyle(fontSize: 18.sp,color:  Color(0xff555555),fontWeight: FontWeight.bold)),
            SizedBox(height: 5.h,),
            Padding(
              padding:  EdgeInsets.symmetric(horizontal: 5.w),
              child: Column(
                children: [
                  Container(
                    height: 7.h,
                    width: 100.w,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.shade300,
                            blurRadius: 0.5,
                            spreadRadius: 0.5,
                            offset: Offset(0.5, 0.5),
                          )
                        ],
                        borderRadius: BorderRadius.circular(13)),
                    child: Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 5.w),
                      child: Row(
                       children: [
                         Text("Dark mode",style: TextStyle(color: Colors.teal.shade400,fontSize: 13.sp),),
                         Spacer(),
                         Switch(value: true, onChanged: (value) {
                         },activeColor: Colors.teal.shade400),
                       ],
                      ),
                    ),
                  ),
                  SizedBox(height: 2.h,),
                  ProfileMenu(
                    icon: Icons.security_update_good,
                    press: () {
                      //Navigator.push(context, MaterialPageRoute(builder: (context) => Profile_page(),));
                    },
                    text: "Account Setting",
                  ),
                  SizedBox(height: 2.h,),
                  ProfileMenu(
                    icon: Icons.report,
                    press: () {
                     // Navigator.push(context, MaterialPageRoute(builder: (context) => Profile_page(),));
                    },
                    text: "Report Bug",
                  ),
                  SizedBox(height: 2.h,),
                  ProfileMenu(
                    icon: Icons.policy,
                    press: () {
                      // Navigator.push(context, MaterialPageRoute(builder: (context) => Profile_page(),));
                    },
                    text: "Privacy policy",
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class ProfileMenu extends StatelessWidget {
  final icon,text;
  final VoidCallback press;
  const ProfileMenu({Key? key, this.icon, this.text, required this.press}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  InkWell(
      onTap: press,
      child: Container(
        height: 7.h,
        width: 130.w,
        decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.shade300,
                blurRadius: 0.5,
                spreadRadius: 0.5,
                offset: Offset(0.5, 0.5),
              )
            ],
            borderRadius: BorderRadius.circular(13)),
        child: Padding(
          padding:  EdgeInsets.symmetric(horizontal: 5.w),
          child: Row(
            children: [
              Icon(icon,color: Colors.teal.shade400,),
              SizedBox(width: 6.w,),
              Text(text,style: TextStyle(color: Colors.teal.shade400,fontSize: 13.sp),),
              Spacer(),
            //  Icon(Icons.arrow_forward_ios_rounded, color: Colors.teal.shade400),
            ],
          ),
        ),
      ),
    );
  }
}
