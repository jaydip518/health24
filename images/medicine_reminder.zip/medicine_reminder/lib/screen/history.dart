import 'package:flutter/material.dart';

class HISTORY_SCREEN extends StatefulWidget {
  const HISTORY_SCREEN({Key? key}) : super(key: key);

  @override
  State<HISTORY_SCREEN> createState() => _HISTORY_SCREENState();
}

class _HISTORY_SCREENState extends State<HISTORY_SCREEN> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
