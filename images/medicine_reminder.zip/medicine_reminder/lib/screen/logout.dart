import 'package:flutter/material.dart';

class LOGOUT extends StatefulWidget {
  const LOGOUT({Key? key}) : super(key: key);

  @override
  State<LOGOUT> createState() => _LOGOUTState();
}

class _LOGOUTState extends State<LOGOUT> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
