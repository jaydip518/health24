import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:medicine_reminder/screen/bottom_navigation_bar.dart';
import 'package:medicine_reminder/screen/sign_in_screen.dart';
import 'package:medicine_reminder/screen/sign_up_screen.dart';
import 'package:medicine_reminder/screen/splash_screen.dart';
import 'package:medicine_reminder/screen/welcome_screen.dart';
import 'package:medicine_reminder/screen/welcome_sign_up.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(statusBarColor: Colors.teal.shade400,));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return  MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'medicine reminder',
        theme: ThemeData(
          textTheme: GoogleFonts.mulishTextTheme(
              Theme.of(context).textTheme
          ).apply(bodyColor: Colors.black),
          pageTransitionsTheme: PageTransitionsTheme(builders: {
            TargetPlatform.iOS:FadeUpwardsPageTransitionsBuilder(),
            TargetPlatform.android:FadeUpwardsPageTransitionsBuilder(),
          }),
        ),
        home: SPLASH_SCREEN(),
      );
    });
  }
}
