package com.example.medicine_reminder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
